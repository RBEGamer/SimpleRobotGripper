# INA3221 Library
Arduino library for INA3221 current and voltage sensor.
